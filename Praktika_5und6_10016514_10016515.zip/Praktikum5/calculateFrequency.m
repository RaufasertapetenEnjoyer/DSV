function fn = calculateFrequency(fa1, n)
    fn = 2^((n - 49) / 12) * fa1;
end